<?php

namespace App\Http\Livewire;


class FavouriteVendorLivewire extends BaseLivewireComponent
{

    public function render()
    {
        return view('livewire.favourite_vendors');
    }
}
